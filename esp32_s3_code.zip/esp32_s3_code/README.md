Continuously sends telemetry data (robot yaw, distance, etc.) to connected clients and reponds to the commands for controlling the robot's movement (e.g., TURN, MOVE).
